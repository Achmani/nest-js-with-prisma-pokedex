import { Module } from '@nestjs/common';
import { MonsterModule } from './monsters/monster.module';
import { PrismaService } from './prisma.service';

@Module({
  imports: [MonsterModule],
  providers: [PrismaService],
})
export class AppModule {}
