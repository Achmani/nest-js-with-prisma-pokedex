import { Module } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { MonsterController } from './monster.controller';
import { MonsterGateway } from './gateways/monster.gateway';
import { MonsterRepository } from './repository/monster.repository';
import { MonsterTypeRepository } from './repository/monster-type.repository';

@Module({
    imports: [],
    providers: [PrismaService, MonsterTypeRepository, MonsterRepository, MonsterGateway],
    controllers: [MonsterController],
})
export class MonsterModule { }
