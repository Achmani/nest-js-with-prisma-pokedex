import {
    Body,
    Controller,
    Get,
    Param,
    Post,
} from '@nestjs/common';
import { MonsterGateway } from './gateways/monster.gateway';
import { MonsterCreateRequest } from './dtos/monster.create.request';
@Controller('monster')
export class MonsterController {
    constructor(
        private readonly monsterGateway: MonsterGateway,
    ) { }

    @Get('/:skip/:take')
    async getMonster(@Param('skip') skip: number, @Param('take') take: number) {
        return await this.monsterGateway.monsters();
    }

    @Post('/')
    async createMonster(@Body() request: MonsterCreateRequest) {
        return await this.monsterGateway.createMonster(request);
    }

}