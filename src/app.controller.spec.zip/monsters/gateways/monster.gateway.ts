import { Monster, MonsterType, Prisma } from "@prisma/client";

import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { MonsterResponse } from "../dtos/monster.response";
import { MonsterCreateRequest } from "../dtos/monster.create.request";
import { MonsterRepository } from "../repository/monster.repository";
import { MonsterTypeRepository } from "../repository/monster-type.repository";
import { randomUUID } from "crypto";

@Injectable()
export class MonsterGateway {

    constructor(
        private monsterRepository: MonsterRepository,
        private monsterTypeRepository: MonsterTypeRepository
    ) { }

    async monsters(): Promise<MonsterResponse[]> {
        type MonstersWithType = Prisma.PromiseReturnType<typeof this.monsterRepository.monsters>
        let result: MonstersWithType = await this.monsterRepository.monsters({});
        return this.getMonsterResponse(result);
    }

    private getMonsterResponse(monsters: (Monster & { monsterType: MonsterType[] })[]): MonsterResponse[] {
        let results: MonsterResponse[] = [];
        monsters.forEach(monster => {
            results.push(this.constructMonsterResponse(monster));
        })
        return results;
    }

    private constructMonsterResponse(monster: Monster & { monsterType: MonsterType[] }): MonsterResponse {
        return { monsterId: monster.monsterId, monsterName: monster.monsterName, monsterType: monster.monsterType.flatMap((element) => element.monsterTypeName) }
    }

    async createMonster(monster: MonsterCreateRequest) {
        let monsterType = await this.monsterTypeRepository.monsterType(monster.monster_type);
        if (this.checkMonsterType(monsterType)) {
            try {
                return this.monsterRepository.createMonster({ monsterId: randomUUID(), monsterName: monster.monster_name, monsterType: { connect: { monsterTypeName: "fire" } } });
            } catch (error) {
                console.log("ini apa");
                console.log(error);
            }
        }
        throw new HttpException('Monster Type not found', HttpStatus.FORBIDDEN);
    }

    private checkMonsterType(monsterType: MonsterType[]): boolean {
        if (monsterType.length > 0) {
            return true;
        }
        return false;
    }

}