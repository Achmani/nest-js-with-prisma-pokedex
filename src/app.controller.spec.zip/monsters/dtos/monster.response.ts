export type MonsterResponse = {
    monsterId: string
    monsterName: string
    monsterType: string[]
}