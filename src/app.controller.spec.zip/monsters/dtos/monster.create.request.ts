export class MonsterCreateRequest {
    monster_name: string;
    monster_type: string[];
}