import { Injectable } from "@nestjs/common";
import { Monster, Prisma } from "@prisma/client";
import { PrismaService } from "../../prisma.service";

@Injectable()
export class MonsterRepository {

    constructor(
        private prisma: PrismaService
    ) { }

    async monsters(params: {
        skip?: number;
        take?: number;
        cursor?: Prisma.MonsterWhereUniqueInput;
        where?: Prisma.MonsterWhereUniqueInput;
        orderBy?: Prisma.MonsterOrderByWithRelationInput;
    }) {
        const { skip, take, cursor, where, orderBy } = params;
        return this.prisma.monster.findMany({
            include: { monsterType: true },
            skip,
            take,
            cursor,
            where,
            orderBy,
        });
    }

    async createMonster(data: Prisma.MonsterCreateInput): Promise<Monster> {
        console.log("createMonster")
        console.log(data);
        try {
            return await this.prisma.monster.create({
                data,
            });
        } catch (error) {
            console.log("------");
            console.log(error);
        }
    }

}